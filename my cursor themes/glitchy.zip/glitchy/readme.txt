﻿=== Glitchy Cursor Set ===

By: MintPepper (http://www.rw-designer.com/user/61590)

Download: http://www.rw-designer.com/cursor-set/glitchy

Author's description:

Glitching (And Insane) Cursor
Text Cursor Added
Blinking Cursor added


==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.